# DSA 06/10
Aula de Desenvolvimento de Serviços e APIs - TRANSAÇÕES - 06/10 

# 🌹 FLORICULTURA

#### Documentação do Sequelize sobre transações: 
+ https://sequelize.org/docs/v6/other-topics/transactions/

### Lembrando que:

**Pra iniciar**:
1. `` npm init -y ``
2. `` npm i express sequelize mysql2 cors ``
3. `` npm i --save-dev nodemon ``
4. `` npx nodemon app ``
5. No VS, criar um "app.js" como o arquivo do repo
6. ⚠️ Alterar o "package.json", adicionando a linha `` "type": "module", `` após a linha de "main": "index.js","

![image](https://github.com/CarolinaSFreitas/api-floricultura-0610/assets/99994934/f036773f-00af-4035-a477-ba0604783467)


